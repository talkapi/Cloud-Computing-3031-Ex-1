import json
import boto3
import random
from datetime import datetime, timezone
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('cloud-computing-3031-ex1')

def generate_ticket_id():
    return f"{random.randint(10000, 99999)}"

def calculate_charge(minutes_parked):
    rate_per_hour = 10.0
    rate_per_15_min = rate_per_hour / 4
    total_charge = ((minutes_parked + 15) // 15) * rate_per_15_min
    return round(total_charge, 2)

def entry(event, context):
    license_plate = event['queryStringParameters']['plate']
    parking_lot = event['queryStringParameters']['parkingLot']
    
    ticket_id = generate_ticket_id()
    record_time = datetime.now(timezone.utc).isoformat()
    
    table.put_item(
        Item={
            'ticket_id': ticket_id,
            'record_time': record_time,
            'parking_lot': parking_lot,
            'license_plate': license_plate
        }
    )
    
    return {
        'statusCode': 200,
        'body': {'ticket_id': ticket_id}
    }

def exit(event, context):
    ticket_id = event['queryStringParameters']['ticketId']
    
    response = table.get_item(
        Key={'ticket_id': ticket_id}
    )
    
    if 'Item' not in response:
        return {
            'statusCode': 404,
            'body': {'error': 'Ticket ID not found'}
        }
    
    item = response['Item']
    record_time = datetime.fromisoformat(item['record_time'])
    current_time = datetime.now(timezone.utc)
    
    parked_minutes = (current_time - record_time).total_seconds() / 60
    total_charge = calculate_charge(parked_minutes)
    
    # Delete the record from the database
    table.delete_item(
        Key={'ticket_id': ticket_id}
    )
    
    return {
        'statusCode': 200,
        'body': {
            'license_plate': item['license_plate'],
            'total_parked_minutes': round(parked_minutes),
            'parking_lot': item['parking_lot'],
            'charge': total_charge
        }
    }

def lambda_handler(event, context):
    print('event')
    route = event['resource']
    if route == '/entry':
        return entry(event, context)
    elif route == '/exit':
        return exit(event, context)
    else:
        return {
            'statusCode': 400,
            'body': {'error': 'Unsupported route'}
        }
